<!DOCTYPE HTML>
<?php
$conn = mysqli_connect("db4free.net:3306","mcetcse309","vengatesh","college_bus");
if (!$conn)
{
    echo "Not connected";
    
}
else
{
    echo "   ";
}
?>